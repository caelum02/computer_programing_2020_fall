package security.key;

public class BankSymmetricKey extends BankKey {
    public BankSymmetricKey(String value) {
        super(value);
    }
}
