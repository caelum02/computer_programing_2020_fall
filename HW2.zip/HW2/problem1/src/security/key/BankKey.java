package security.key;

public class BankKey{
    public String value;
    public BankKey(String value){
        this.value = value;
    }
}
