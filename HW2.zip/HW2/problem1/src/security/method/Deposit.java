package security.method;

public class Deposit extends RequestMethod {
}
