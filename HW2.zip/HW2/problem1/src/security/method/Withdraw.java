package security.method;

public class Withdraw extends RequestMethod{
}
