

import java.util.*;

public class User {
    private String username;
    public User(String username) { this.username = username; }
    @Override
    public String toString() {
        return username;
    }

    public String getUsername() {
        return username;
    }
}
